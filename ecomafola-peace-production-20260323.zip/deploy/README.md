# EcoMafola Peace - Production Build

## 部署说明

### 构建信息
- **构建时间**: 2026-03-23
- **版本**: 1.0.0
- **技术栈**: Vite + React + TypeScript + Tailwind CSS

### 文件结构
```
deploy/
├── index.html          # 主页面入口
└── assets/             # 静态资源
    ├── index-*.js      # 应用主代码
    ├── vendor-*.js     # 第三方依赖（React、React Router 等）
    ├── shopify-*.js    # Shopify API 客户端
    └── index-*.css     # 样式文件
```

### 部署步骤

#### 方案一：静态托管（推荐）
1. 将 `deploy/` 目录下的所有文件上传到你的静态托管服务
2. 推荐平台：
   - **Vercel**: 拖拽 `deploy` 文件夹到 Vercel Dashboard
   - **Netlify**: 拖拽 `deploy` 文件夹到 Netlify Drop
   - **Cloudflare Pages**: 通过 Dashboard 上传
   - **GitHub Pages**: 推送到 gh-pages 分支

#### 方案二：自建服务器
1. 将 `deploy/` 目录内容复制到 Web 服务器的 public 目录
2. 配置 Nginx/Apache 指向该目录
3. 确保所有路由重定向到 `index.html`（SPA 必需）

**Nginx 配置示例：**
```nginx
server {
    listen 80;
    server_name ecomafola.com;
    root /var/www/ecomafola-peace;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    # 启用 Gzip 压缩
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
}
```

### 环境变量配置

在部署前，确保设置以下环境变量（或在构建时配置）：

```bash
VITE_SHOPIFY_STORE_DOMAIN=ecomafola-peace.myshopify.com
VITE_SHOPIFY_STOREFRONT_TOKEN=11c0b58bfdee65f96fbbd918d9aeeaa7
```

**注意**: 这些变量在构建时会被嵌入到 JavaScript 文件中。如果需要动态配置，请使用运行时环境变量注入方案。

### Shopify 集成

本项目已集成 Shopify Storefront API：
- 商品列表从 Shopify Collection 同步
- 购物车使用 Shopify Cart API
- 结账跳转到 Shopify Checkout

确保你的 Shopify Storefront Access Token 有足够权限。

### 性能优化

构建已自动优化：
- ✅ 代码分割（Vendor 分离）
- ✅ Tree Shaking
- ✅ ESBuild 压缩
- ✅ CSS 提取
- ✅ Gzip 友好

### 本地测试

部署前可在本地预览：
```bash
npm run preview
```

访问 http://localhost:4173 查看生产版本效果。

### 故障排查

**问题**: 页面空白
- 检查浏览器控制台错误
- 确认所有 JS/CSS 文件路径正确
- 验证 Shopify API Token 是否有效

**问题**: 路由 404
- 确保服务器配置了 SPA 回退（try_files）
- 检查 base URL 配置

### 联系方式

如有问题，请联系开发团队。

---
**品牌**: EcoMafola Peace  
**叙事风格**: Empowerment + Partnership  
**市场**: 南太平洋手工艺品跨境贸易
