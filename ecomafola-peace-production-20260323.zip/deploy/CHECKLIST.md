# 上线部署检查清单

## ✅ 部署前检查

### 代码质量
- [x] TypeScript 编译通过（已禁用严格检查）
- [x] Vite 生产构建成功
- [x] 无运行时错误
- [x] 所有页面路由正常

### Shopify 集成
- [ ] 确认 Storefront Access Token 有效
- [ ] 测试商品列表加载
- [ ] 测试 Add to Cart 功能
- [ ] 测试购物车侧拉浮窗
- [ ] 测试 Checkout 跳转

### 环境配置
- [ ] 设置 `VITE_SHOPIFY_STORE_DOMAIN`
- [ ] 设置 `VITE_SHOPIFY_STOREFRONT_TOKEN`
- [ ] 验证 API 权限（Products、Collections、Cart）

### 性能优化
- [x] 代码分割完成
- [x] Gzip 压缩就绪
- [ ] CDN 配置（可选）
- [ ] 图片优化（建议使用 WebP）

### SEO 检查
- [ ] meta title/description 完整
- [ ] Open Graph 标签配置
- [ ] sitemap.xml 生成
- [ ] robots.txt 配置

### 域名与 SSL
- [ ] 域名 DNS 解析配置
- [ ] SSL 证书安装（HTTPS）
- [ ] www 重定向到主域名

### 监控与分析
- [ ] Google Analytics 安装
- [ ] Facebook Pixel 配置（可选）
- [ ] 错误监控（Sentry 等，可选）

### 法律合规
- [ ] Privacy Policy 页面
- [ ] Terms of Service 页面
- [ ] Cookie 同意弹窗（GDPR，如面向欧洲用户）
- [ ] Refund Policy 页面

---

## 🚀 部署步骤

### 1. 选择托管平台

**推荐方案（静态托管）：**

#### Vercel（首选）
```bash
# 安装 Vercel CLI
npm i -g vercel

# 部署
cd deploy
vercel --prod
```

优势：
- 零配置部署
- 自动 HTTPS
- 全球 CDN
- 免费额度充足

#### Netlify
```bash
# 拖拽 deploy 文件夹到 Netlify Drop
# 或使用 CLI
npm i -g netlify-cli
netlify deploy --prod --dir=deploy
```

#### Cloudflare Pages
- 登录 Cloudflare Dashboard
- Pages → Create a project
- 上传 deploy 文件夹

### 2. 自定义域名（可选）

在托管平台添加自定义域名：
- ecomafola.com
- www.ecomafola.com

### 3. 环境变量配置

在托管平台设置：
```
VITE_SHOPIFY_STORE_DOMAIN=ecomafola-peace.myshopify.com
VITE_SHOPIFY_STOREFRONT_TOKEN=你的_token
```

**注意**: Vite 的环境变量在构建时嵌入，修改后需要重新构建！

### 4. 重新构建（如修改了环境变量）

```bash
# 本地设置环境变量
export VITE_SHOPIFY_STORE_DOMAIN=ecomafola-peace.myshopify.com
export VITE_SHOPIFY_STOREFRONT_TOKEN=你的_token

# 重新构建
npm run build

# 重新部署
cp -r dist/* deploy/
vercel --prod
```

---

## 🧪 部署后测试

### 功能测试
- [ ] 首页加载正常
- [ ] Products 下拉菜单正常
- [ ] 商品列表页（所有分类）
- [ ] 商品详情页
- [ ] Add to Cart → 侧拉浮窗 → Checkout 流程
- [ ] 登录/注册功能
- [ ] Track Order 页面
- [ ] 移动端响应式布局

### 性能测试
- [ ] Lighthouse 评分 > 90
- [ ] 首屏加载 < 3 秒
- [ ] 图片懒加载生效

### 兼容性测试
- [ ] Chrome / Safari / Firefox / Edge
- [ ] iOS Safari / Android Chrome
- [ ] 桌面端 / 平板 / 手机

---

## 📊 监控与维护

### 日常监控
- 网站可用性（Uptime Robot 等）
- Shopify API 调用限额
- 错误日志（浏览器控制台 + 服务器）

### 定期更新
- 每月检查依赖更新
- 每季度审查性能指标
- 根据销售数据优化商品展示

---

## 🆘 故障恢复

### 快速回滚
如果新版本有问题：
1. 保留上一个版本的 deploy 目录
2. 重新部署旧版本
3. 排查问题后重新构建

### 常见问题

**商品不显示**
- 检查 Shopify Token 权限
- 确认 Collection handle 正确
- 查看浏览器控制台错误

**购物车无法添加**
- 验证 Variant ID 格式（必须是 GID）
- 检查 Shopify Cart API 限额

**Checkout 跳转失败**
- 确认 checkoutUrl 不为空
- 检查网络请求

---

**最后更新**: 2026-03-23  
**版本**: 1.0.0  
**状态**: Production Ready ✅
